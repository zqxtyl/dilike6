<template>
  <div>
    设备管理类型
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },

  created() {

  },

  methods: {

  }
}
</script>

<style scoped>

</style>
