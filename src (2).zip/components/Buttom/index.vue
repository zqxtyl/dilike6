<template>
  <div>
    <el-button class="color" type="primary" icon="el-icon-circle-plus-outline" size="small">新增</el-button>
  </div>
</template>

<script>
export default {
  data() {
    return {

    }
  },

  created() {

  },

  methods: {

  }
}
</script>

<style scoped>
.color{
    background-color: #FF702B;
    border: none;
}
</style>
